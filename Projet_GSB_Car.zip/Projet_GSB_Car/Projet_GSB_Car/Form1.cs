﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet_GSB_Car
{
    public partial class Form1 : Form
    {
        private string immatriculation;
        private string marque;
        private string modele;
        private double puissance_fiscale;
        private double kilometrage;
        private int intervalle_revision;
        private DateTime premiere_immatriculation;
        private double prix_achat;
        private bool type;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void TabPage1_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
           
        }

        private void TabPage2_Click(object sender, EventArgs e)
        {

        }
    }
}
